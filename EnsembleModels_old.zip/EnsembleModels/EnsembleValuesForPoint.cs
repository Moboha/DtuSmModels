﻿using System;

using DtuSmModels;


namespace EnsembleModels
{
    public class EnsembleValuesForPoint
    {

        private bool bTransform = false;//true if value should be transformed with some observation operator. 
        private readonly MainModel[] Models;
        private readonly Outlet[] outlets;
        public double[] Values;
        private readonly SmOutput.OutputType _type;

        


        public EnsembleValuesForPoint(MainModel[] models, SmOutput.OutputType type, string name)
        {
            Models = models;
            Values = new double[Models.Length];



            _type = type;

            switch (_type)
            {
                case SmOutput.OutputType.linkFlowTimeSeries:
                    throw new NotImplementedException();
                    break;
                case SmOutput.OutputType.nodeVolume:
                    throw new NotImplementedException();
                    break;
                case SmOutput.OutputType.outletFlowTimeSeries:

                    outlets = new Outlet[Models.Length];
                    
                    bool bsuccess = false;
                    int outletIndexInNodeArray = int.MaxValue;
                    foreach (int i in Models[0].iOutlets)
                    {
                        if (Models[0].Nodes[i].name == name) outletIndexInNodeArray = i;

                    }
                    if (outletIndexInNodeArray == int.MaxValue) throw new Exception("could not find outlet");

                    for (int i = 0; i < Models.Length; i++)
                    {
                        outlets[i] = (Outlet)models[i].Nodes[outletIndexInNodeArray];
                    }
    
                    break;
                default:
                    break;
            }



        }


        public double[] GetValues()
        {   
            switch (_type)
            {   
                case SmOutput.OutputType.linkFlowTimeSeries:
                    throw new NotImplementedException();
                    break;
                case SmOutput.OutputType.nodeVolume:
                    throw new NotImplementedException();
                    break;
                case SmOutput.OutputType.outletFlowTimeSeries:
                    for (int i = 0; i < Values.Length; i++)
                    {
                        Values[i] = outlets[i].flow;//MB: rewrite to avoid this unnecessary looping and copying. 
                    }


                    break;
                default:
                    break;
            }

            return Values;

        }






        




    }
}
 